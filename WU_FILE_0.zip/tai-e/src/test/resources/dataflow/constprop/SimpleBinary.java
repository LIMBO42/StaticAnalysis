class SimpleBinary {

    int zrithmetic() {
        int x = 1, y = 2;
        int z = x + y;
        return z;
    }

    boolean condition() {
        int x = 1, y = 2;
        boolean z = x == y;
        return z;
    }
    
    int shift() {
        int x = 1, y = 2;
        int z = x << y;
        return z;
    }

    int bitwise() {
        int x = 1, y = 2;
        int z = x | y;
        return z;
    }

    int nac(int p) {
        int x = 1, y = p;
        int z = x * y;
        return z;
    }
}
