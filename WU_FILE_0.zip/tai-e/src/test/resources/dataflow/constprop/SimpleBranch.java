class SimpleBranch {

    static void NAC(int p) {
        int x;
        if (p > 0) {
            x = 1;
        } else {
            x = 2;
        }
        int y = x;
    }
}
