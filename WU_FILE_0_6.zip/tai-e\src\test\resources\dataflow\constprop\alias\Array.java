class Array {

    public static void main(String[] args) {
        int[] a1 = {1, 2, 3, 5, 7, 9};
        int x = a1[3];
        int[] a2 = new int[3];
        a2[0] = 666;
        a2[1] = 888;
        a2[2] = 999;
        int y = a2[1];
        int z = a2[2];
    }
}
