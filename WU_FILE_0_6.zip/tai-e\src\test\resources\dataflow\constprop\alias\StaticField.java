class StaticField {

    static int f;

    public static void main(String[] args) {
        f = 100;
        int x = f;
    }
}
